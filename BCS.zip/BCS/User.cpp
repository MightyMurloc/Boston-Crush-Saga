#include "User.h"
using namespace std;

user::user()
{
	this->name = "New player";
	this->score = 0;
}

string user::getName()
{
	return this->name;
}

int user::getScore()
{
	return this->score;
}

void user::setScore(int score)
{
	this->score = score;
}

void user::exportScore(char * fName, int score)
{
	ofstream outFile;
	outFile.open(fName, ofstream::out | ofstream::app);
	if (outFile) {
		outFile << this->getName() << ": " << this->getScore() << endl;
	}
	outFile.close();
}
