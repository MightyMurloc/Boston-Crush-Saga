#pragma once
#include <fstream>
#include <string>
#include <iostream>
using namespace std;

class user {
	string name;
	int score;
public:
	user();
	string getName();
	int getScore();
	void setScore(int score);
	void exportScore(char *fName, int score);
};